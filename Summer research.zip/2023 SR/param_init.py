import type_def
import datetime
import pandas as pd

def initialdate(date, move):
    timestamp = datetime.datetime.strptime(date, "%Y/%m/%d")
    timestamp += datetime.timedelta(days = move)
    return timestamp.strftime("%Y/%m/%d")

Medical = type_def.Department("C7", "medical")
Private = type_def.Department("C8", "private")
Ortho = type_def.Department("B9", "ortho")
Surgical_1 = type_def.Department("A10", "surgical")
Surgical_2 = type_def.Department("B10", "surgical")

Departments = [Medical, Private, Ortho, Surgical_1, Surgical_2]

Rooms = []
Beds = []
df = pd.read_csv("room_status.csv")
for i in range(0, df.__len__()):
    room = type_def.Room(list(df.loc[i]))
    for j in range(1,room.capacity+1):
        bed = type_def.Bed(list(df.loc[i]), j)
        Beds.append(bed)
    Rooms.append(room)

Patients = []
def init_Patients(round_num):
    Patients = []
    filenumber = str(round_num)
    df = pd.read_csv("datasets\dataset" + filenumber + ".csv")
    for i in range(0, df.__len__()):
        patient = type_def.Patient(df.loc[i])
        patient.admission = initialdate(patient.admission, 0)
        patient.discharge = initialdate(patient.discharge, 0)
        Patients.append(patient)
    return Patients