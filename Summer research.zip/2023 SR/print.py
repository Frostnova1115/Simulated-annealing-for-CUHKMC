# full code available at:
# https://github.com/Frostnova1115/Simulated-annealing-for-CUHKMC/blob/main/main.py
import copy
import openpyxl


def simulatedAnnealing(currentSchedule):
    T = 1000  # temperature
    k = 0.9  # cooling rate
    maxStep = 25  # max step number
    step = 0  # step finished
    schedule = copy.deepcopy(currentSchedule)  # initial solution
    solution = copy.deepcopy(currentSchedule)  # current best solution* date
    while step < maxStep:
        temp_schedule = copy.deepcopy(schedule)
        for i in range(0, 20):
            new_schedule = neighborFunction(temp_schedule)  # find neighbor
            E_new = objectiveFunction(new_schedule)  # find neighbor's energy
            E_temp = objectiveFunction(temp_schedule)  # find temp's energy
            delta = E_new - E_temp
            if delta < 0:
                temp_schedule = copy.deepcopy(new_schedule)  # accept good solution
                # update best solution if possible
                # find best solution's energy
                E_solution = objectiveFunction(solution)
                if E_solution > E_temp:
                    solution = copy.deepcopy(temp_schedule)
            else:
                p = math.exp(-delta / T)  # accept bad solution with probability p
                pull = random.random()
                if pull < p:
                    temp_schedule = copy.deepcopy(new_schedule)
            E_schedule = objectiveFunction(schedule)  # update current schedule
            if E_schedule > E_temp:
                schedule = copy.deepcopy(temp_schedule)
        step += 1  # update parameters
        T = k * T
    return solution


def outPutSchedule(current_schedule, admission_num, exe_time):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    red = PatternFill(start_color="00FF6D6D", end_color="00FF6D6D", fill_type="solid")
    blue = PatternFill(start_color="008FAAFF", end_color="008FAAFF", fill_type="solid")
    yellow = PatternFill(start_color="00A5FF5B", end_color="00A5FF5B", fill_type="solid")
    date_to_column = {}
    id_to_row = {}

    for i in range(1, 31):  # print date row
        sheet.cell(row=1, column=i + 1, value=dayCount(begin_date, i - 1)).alignment = Alignment(horizontal='center',
                                                                                                 vertical='center')
        date_to_column[dayCount(begin_date, i - 1)] = i + 1

    for i in range(1, 17):  # print room number column
        sheet.cell(row=i + 1, column=1, value=Beds[i - 1].id).alignment = Alignment(horizontal='center',
                                                                                    vertical='center')
        id_to_row[Beds[i - 1].id] = i + 1

    for i in range(1, sheet.max_row + 1):  # set width and height
        sheet.row_dimensions[i].height = 15
    for i in range(1, sheet.max_column + 1):
        sheet.column_dimensions[get_column_letter(i)].width = 12.5
    occupied = 0  # load schedule
    for i in current_schedule:
        for j in current_schedule[i]:
            row_num = id_to_row[i]
            start = date_to_column[j.admission]
            end = date_to_column[j.discharge]
            date_stamp = start
            if j.admission < Date_now:
                color = red
            else:
                color = blue
            while date_stamp <= end:
                occupied += 1
                if date_stamp == start:
                    sheet.cell(row=row_num, column=date_stamp, value=j.id).fill = color
                else:
                    sheet.cell(row=row_num, column=date_stamp).fill = color
                date_stamp += 1

    sheet.cell(row=18, column=2, value=str(round(float(occupied) / (32 * 30) * 100, 2)) + '%')  # occupancy
    sheet.cell(row=18, column=1, value="Occupancy").alignment = Alignment(horizontal='center', vertical='center')
    sheet.cell(row=19, column=2, value=str(round(float(admission_num) / (50) * 100, 2)) + '%')  # admission rate
    sheet.cell(row=19, column=1, value="Admission").alignment = Alignment(horizontal='center', vertical='center')
    sheet.cell(row=20, column=2, value=exe_time)  # execution time
    sheet.cell(row=20, column=1, value="Time").alignment = Alignment(horizontal='center', vertical='center')

    print("Occupancy = ", str(round(float(occupied) / (32 * 30) * 100, 2)) + '%')
    workbook.save(filename="Schedules_floating\Schedule" + str(dataset) + ".xlsx")
    workbook.close()


def optimize(raw_schedule, round_num):
    schedule = copy.deepcopy(raw_schedule)
    st = datetime.datetime.now()
    count = 0
    while count < 55 and len(WaitingList) > 0:  # test SA
        count += 1
        pos = 0
        bed = insert(WaitingList[pos], schedule)
        if bed != -1:
            Patients.append(WaitingList[pos])
            schedule[bed].append(WaitingList[pos])
            del WaitingList[pos]
        schedule = simulatedAnnealing(schedule)
        ed = datetime.datetime.now()
        exe_time = (ed - st).seconds
        if count <= 1:
            print("Dataset number: ", round_num)
        if len(WaitingList) == 0 or count == 55:
            print("number: ", count)
            print("bed = ", bed)
            print("Length of WL: ", len(WaitingList))
            print("evaluation: ", objectiveFunction(schedule, eval=1))
            print("execution time = ", exe_time)
            outPutSchedule(schedule, len(Patients), exe_time)
            print("----------------")
    return schedule


Departments = []
Rooms = []
Beds = []
Patients = []
WaitingList = []
begin_date = ''
dataset = 0
for dataset in range(1, 11):
    # initialization parameters
    param_init.init_Patients(dataset)
    Departments = copy.deepcopy(param_init.Departments)
    Rooms = copy.deepcopy(param_init.Rooms)
    Beds = copy.deepcopy(param_init.Beds)
    Patients = []
    WaitingList = copy.deepcopy(param_init.init_Patients(dataset))
    begin_date = dayCount(min([i.admission for i in WaitingList]), 0)
    Date_now = begin_date
    # Room id to idex
    id_to_index = {}
    for k in range(0, len(Rooms)):
        id_to_index[Rooms[k].id] = k
    Schedule = dict([(Beds[i].id, []) for i in range(len(Beds))])
    Schedule = optimize(Schedule, dataset)
