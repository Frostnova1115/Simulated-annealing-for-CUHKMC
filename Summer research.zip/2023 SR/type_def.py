class Room:
    def __init__(self, data):
        self.id = data[1]
        self.capacity = data[2]
        self.floor = data[3]
        self.location = data[4]
        self.feature = data[5]
        self.gender = ""
        self.number = 0


class Bed:
    def __init__(self, data, num):
        self.room = data[1]
        self.floor = data[3]
        self.location = data[4]
        self.feature = data[5]
        self.num = num
        self.id = data[1] + ' ' + str(num)


class Department:
    def __init__(self, area, name):
        self.area = area
        self.name = name


class Patient:
    def __init__(self, data):
        self.id = data[1]
        self.gender = data[2]
        self.admission = data[3]
        self.discharge = data[4]
        self.preference = data[5]
        self.department = data[6]
