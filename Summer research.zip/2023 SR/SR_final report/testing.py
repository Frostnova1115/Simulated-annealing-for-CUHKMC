import functools
import os
from matplotlib import pyplot as plt
import random
import math
import numpy as np
# from scipy.optimize import minimize

def f(x):
    return x**4 - 2 * x**3 - 4 * x**2 + 8*x

x = [i/10000  for i in range(-30000,30000)]
y = [f(i) for i in x]
plt.plot(x,y)

def simulate_annealing():
    T = 100000 # temperature
    ans = (random.random() - 0.5) * 6
    best = ans
    k = 0
    step_len = 5
    while k < 20:
        temp_ans = ans
        for i in range(0, 20):
            new_ans = temp_ans + (random.random() -0.5) * step_len
            delta = f(new_ans) - f(temp_ans)
            if delta < 0:
                temp_ans = new_ans
            else:
                p = min(math.exp(-delta/T),1)
                pull = random.random()
                # print("x0: ", temp_ans,", x:",new_ans,", p:",p,", pull",pull)
                if pull < p:
                    temp_ans = new_ans
            if f(temp_ans) - f(ans) < 0:
                ans = temp_ans

        k += 1
        T = 0.9 * T
        step_len = max(0.9 * step_len, 1)

    # print(ans)
    # plt.annotate("x1",xy=(ans,f(ans)), xycoords='data',
    #              xytext=(+10,+30), textcoords='offset points', fontsize = 16,
    #              arrowprops=dict(arrowstyle="->", connectionstyle='arc3,rad=0.2'))
    # plt.show()
    return ans



final_ans = []
correct = 0
for i in range(1, 1000):
    temp = simulate_annealing()
    final_ans.append(temp)
    if temp < 0:
        correct += 1
    print(i,"%",end='\r')

print(correct)
print(len(final_ans))
print(correct/len(final_ans))