import numpy as np

##No_Room=3
##No_Bed=7
##Ward=1
##Twin=1
##Single=1
#basic information about the hospital

gender_penalty=100
#this penalty can be determined by the users

preference_penalty=50
##this penalty can be determined by the users

class MM():
        """
        Mathematical Modeling part
        """
        def gender_policy(patient_gender, room_gender):
                
                """
                    gender policy
                    Parameter:
                        patient_gender : The gender of patient.
                """

                gender_weight=[]
                #gender_weight是一个数组，用来记录patient在不同房间里的penalty

                if room_gender == "":
                #如果room_gender并没有规定(空房间)，则不会有penalty
                        gender_weight.append(0)
                #如果room_gender和patient_gender相同，则不会有penalty
                elif patient_gender == room_gender:
                        gender_weight.append(0)
                #如果room_gender和patient_gender不相同，则有
                else:
                        gender_weight.append(gender_penalty)


                return gender_weight


        def room_preference(patient_preference, room_type):
                """
                        parameter:
                                patient_preference : The preference of patient.
                                room_type : The type of the room
                """

                preference_weight=[]
                #room_weight是一个数组，用来记录patient的preference在不同房间里的penalty

                if room_type <= patient_preference:
                        preference_weight.append(0)
                                #如果房间类型比病人喜欢的小，则不会有问题
                else:
                        preference_weight.append(preference_penalty)


                return preference_weight

print(MM.gender_policy("M","F"))
print(MM.room_preference(4,2))
