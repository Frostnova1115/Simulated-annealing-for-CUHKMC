import openpyxl
import datetime
import random
import pandas as pd

def dayCount(date, move):
    timestamp = datetime.datetime.strptime(date, "%Y/%m/%d")
    timestamp += datetime.timedelta(days = move)
    return timestamp.strftime("%Y/%m/%d")


begin_date = "2023/06/01"

dep = ["Medical", "Ortho", "Surgical"]
id = []
gender = []
admission = []
discharge = []
preference = []
department = []
with open("dataset1.txt", "r") as f:
    data = f.readlines()
    for line in data:
        info = line.split()
        # id
        id.append(info[1])
        print(info[1], end=' ')
        # gender
        gender.append(info[3])
        print(info[3], end=' ')
        # admission
        admission.append(dayCount(begin_date, int(info[5])))
        print(dayCount(begin_date, int(info[5])), end=' ')
        # discharge
        discharge.append(dayCount(begin_date, int(info[6])))
        print(dayCount(begin_date, int(info[6])), end=' ')
        # preference
        preference.append(int(info[12]))
        print(int(info[12]), end=' ')
        # department
        department.append(dep[random.randint(0, 2)])
        print(dep[random.randint(0, 2)])

def generate(num):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    title = ["ID", "gender", "admission", "discharge", "preference", "department"]

    for i in range(1, 6):
        sheet.cell(row = 1, column = i + 1, value = title[i-1])

    chosen = []

    for row in range(1, 51):
        i = random.randint(1, len(id))
        sheet.cell(row=row + 1, column=1, value=row)
        sheet.cell(row=row + 1, column=2, value=id[i-1])
        sheet.cell(row=row + 1, column=3, value=gender[i-1])
        sheet.cell(row=row + 1, column=4, value=admission[i-1])
        sheet.cell(row=row + 1, column=5, value=discharge[i-1])
        sheet.cell(row=row + 1, column=6, value=preference[i-1])
        sheet.cell(row=row + 1, column=7, value=department[i-1])
        del id[i-1]
        del gender[i-1]
        del admission[i-1]
        del discharge[i-1]
        del preference[i-1]
        del department[i-1]
        print(len(id))

    workbook.save(filename="datasets\dataset"+str(num)+".xlsx")
    workbook.close()


for i in range(10):
    generate(i+1)