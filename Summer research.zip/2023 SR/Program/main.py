import os
import math
import copy
import random
import type_def
import functools
import param_init
import numpy as np
# from scipy.optimize import minimize
from matplotlib import pyplot as plt

room_num = 59
near_nurse_room_num = 8
bed_num = 144

Departments = copy.deepcopy(param_init.Departments)
Rooms = copy.deepcopy(param_init.Rooms)
Patients = copy.deepcopy(param_init.Patients)

# under construction
def objectiveFunction(schedule):
    return 0

# under construction
def neighborFunction(schedule):
    return neighborFunction

def simulatedAnnealing(currentSchedule):
    # temperature
    T = 10000
    # cooling rate
    k = 0.95
    # max step number
    maxStep = 100
    # step finished
    step = 0
    # initial solution
    schedule = currentSchedule
    # current best solution
    solution = currentSchedule
    while step < maxStep:
        temp_schedule = schedule
        for i in range(0, 100):
            # find neighbor
            new_schedule = neighborFunction(temp_schedule)
            # find neighbor's energy
            E_new = objectiveFunction(new_schedule)
            # find temp's energy
            E_temp = objectiveFunction(temp_schedule)
            delta =  E_new - E_temp
            if delta < 0:
                # accept good solution
                temp_schedule = new_schedule
                # update best solution if possible
                # find best solution's energy
                E_solution = objectiveFunction(solution)
                if E_solution > E_temp:
                    solution = temp_schedule
            else:
                # accept bad solution with probability p
                p = math.exp(-delta/T)
                pull = random.random()
                if pull < p:
                    temp_schedule = new_schedule
            # update current schedule
            E_schedule = objectiveFunction(schedule)
            if E_schedule > E_temp:
                schedule = temp_schedule
        # update parameters
        step += 1
        T = k * T
        return solution
