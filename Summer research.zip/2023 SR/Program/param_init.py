import type_def
import pandas as pd

Medical = type_def.department("C7", "medical")
Private = type_def.department("C8", "private")
Ortho = type_def.department("B9", "ortho")
Surgical_1 = type_def.department("A10", "surgical")
Surgical_2 = type_def.department("B10", "surgical")

Departments = [Medical, Private, Ortho, Surgical_1, Surgical_2]

Rooms = []
df = pd.read_csv("room_status.csv")
for i in range(0, df.__len__()):
    room = type_def.room(list(df.loc[i]))
    Rooms.append(room)

Patients = []
df = pd.read_csv("patient.csv")
for i in range(0, df.__len__()):
    patient = type_def.patient(df.loc[i])
    Patients.append(patient)
